import io
import json
import os
import re
import subprocess
from datetime import datetime, timezone

import pandas as pd
import numpy as np

import sdi_utils.gensolution as gs
import sdi_utils.set_logging as slog
import sdi_utils.textfield_parser as tfp
import sdi_utils.tprogress as tp


try:
    api
except NameError:
    class api:

        queue = list()
        class Message:
            def __init__(self, body=None, attributes=""):
                self.body = body
                self.attributes = attributes

        def send(port, msg):
            if port == outports[1]['name']:
                api.queue.append(msg)

        def set_config(config):
            api.config = config

        class config:
            ## Meta data
            config_params = dict()
            tags = {'sdi_utils': '', 'nltk': ''}
            version = "0.0.18"
            operator_name = 'metadata_articles'
            operator_description = "Metadata Articles"
            operator_description_long = "Create metadata from articles."
            add_readme = dict()

            debug_mode = True
            config_params['debug_mode'] = {'title': 'Debug mode',
                                           'description': 'Sending debug level information to log port',
                                           'type': 'boolean'}



def process(msg):

    logger, log_stream = slog.set_logging('metadata_articles', loglevel=api.config.debug_mode)
    logger.info("Process started")
    time_monitor = tp.progress()

    df = msg.body
    att_dict = msg.attributes

    df['url'] = df['url'][:255]
    df['title'] = df['title'][:255]
    df['num_characters'] = df['text'].str.len()
    df.loc[df['media'].isin(['Spiegel','FAZ','Sueddeutsche']),'language'] = 'DE'
    df.loc[df['media'].isin(['Lefigaro', 'Lemonde']), 'language'] = 'FR'
    df.loc[df['media'].isin(['Elpais', 'Elmundo']), 'language'] = 'ES'
    df['date'] = pd.to_datetime(df['date'],format = '%Y-%m-%d',utc = True)
    df = df[['hash_text','language','date','media','url','rubrics','title','num_characters']]

    #datea = datetime.strptime(article['date'], '%Y-%m-%d').replace(tzinfo=timezone.utc)

    logger.debug('Process ended, articles processed {}  - {}  '.format(df.shape[0], time_monitor.elapsed_time()))

    api.send(outports[1]['name'], msg)
    api.send(outports[1]['name'],api.Message(attributes = att_dict, body = df.values.tolist()))


inports = [{'name': 'articles', 'type': 'message.DataFrame', "description": "Message with body as DataFrame."}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"},
            {'name': 'data', 'type': 'message.DataFrame', "description": "Output metadata of articles"}]

api.set_port_callback(inports[0]['name'], process)


def test_operator():
    config = api.config
    config.debug_mode = True
    config.num_important_words = 100
    api.set_config(config)

    doc_file = '/Users/Shared/data/onlinemedia/data/metadata.csv'
    df = pd.read_csv(doc_file,sep=',',nrows=1000000000)
    msg = api.Message(attributes={'file': {'path': doc_file},'format':'pandas'}, body=df)
    process(msg)

    out_file = '/Users/Shared/data/onlinemedia/data/metadata.csv'
    df_list = [pd.DataFrame(d.body) for d in api.queue]
    pd.concat(df_list).to_csv(out_file,index=False)


