# AND Gate - sdi_utils_operators.gate.and_gate (Version: 0.0.1)

Triggers when input on both input ports.

## Inport

* **input1** (Type: any) Trigger, content not used
* **input2** (Type: any) Trigger, content not used

## outports

* **trigger** (Type: string) Trigger next process step

## Config





