# table to csv stream - sdi_utils_operators.table.table_to_csv (Version: 0.0.1)

Converts table to csv stream.

## Inport

* **data** (Type: message.table) Input message with table

## outports

* **log** (Type: string) Logging data
* **csv** (Type: message) Output data as csv

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port
* **separator** - Separator (Type: string) Separator


# Tags
sdi_utils : 

