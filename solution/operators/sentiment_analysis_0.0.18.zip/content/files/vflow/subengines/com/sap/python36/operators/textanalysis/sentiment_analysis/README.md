# Sentiment Analysis - textanalysis.sentiment_analysis (Version: 0.0.1)

Sentiment Analysis using lexicographic approach. 

## Inport

* **articles** (Type: message.dicts) Message with body as dictionary 

## outports

* **log** (Type: string) Logging data
* **data** (Type: message) Output List of sentiment records

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port


# Tags
sdi_utils : textblob : 

