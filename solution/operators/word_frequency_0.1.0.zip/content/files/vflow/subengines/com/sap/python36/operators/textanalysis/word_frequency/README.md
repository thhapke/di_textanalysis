# Word Frequency - textanalysis.word_frequency (Version: 1.0.0)

Calculates word frequency

## Inport

* **words** (Type: message.DataFrame) Message table.

## outports

* **log** (Type: string) Logging data
* **data** (Type: message.DataFrame) Table after regex

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port
* **word_types** - Word types (Type: string) Setting word type selection for delete
* **language_filter** - Language filter (Type: string) Filter for languages of media.


# Tags
sdi_utils : pandas : 

