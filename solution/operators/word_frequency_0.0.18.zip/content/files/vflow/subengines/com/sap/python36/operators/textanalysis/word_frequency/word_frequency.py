import json
import os
import csv
import re
import pandas as pd
import pickle
import collections
import subprocess


import sdi_utils.gensolution as gs
import sdi_utils.set_logging as slog
import sdi_utils.textfield_parser as tfp
import sdi_utils.tprogress as tp



try:
    api
except NameError:
    class api:

        queue = list()
        class Message:
            def __init__(self, body=None, attributes=""):
                self.body = body
                self.attributes = attributes

        def send(port, msg):
            if port == outports[1]['name'] :
                api.queue.append(msg)
            if  port == outports[0]['name'] :
                #print(msg)
                pass

        def set_config(config):
            api.config = config

        class config:
            ## Meta data
            config_params = dict()
            tags = {'sdi_utils': '','pandas': ''}
            version = "0.0.18"
            operator_name = "word_frequency"
            operator_description = "Word Frequency"
            operator_description_long = "Calculates word frequency"
            add_readme = dict()

            debug_mode = True
            config_params['debug_mode'] = {'title': 'Debug mode',
                                           'description': 'Sending debug level information to log port',
                                           'type': 'boolean'}

            word_types = 'PROPN'
            config_params['word_types'] = {'title': 'Word types',
                                           'description': 'Setting word type selection for delete',
                                           'type': 'string'}

            language_filter = 'None'
            config_params['language_filter'] = {'title': 'Language filter', 'description': 'Filter for languages of media.',
                                         'type': 'string'}


def process(msg):

    att_dict = msg.attributes

    logger, log_stream = slog.set_logging('word_index_regex', api.config.debug_mode)
    logger.info("Main Process started. Logging level: {}".format(logger.level))
    time_monitor = tp.progress()

    df = msg.body
    df['COUNT'] = df['COUNT'].astype('int32')

    # word type
    word_types = tfp.read_list(api.config.word_types)
    if word_types :
        df = df.loc[df['TYPE'].isin(word_types)]

    # Language filter
    language_filter = tfp.read_list(api.config.language_filter)
    if language_filter :
        df = df.loc[df['LANGUAGE'].isin(language_filter)]

    df = df.groupby(['LANGUAGE','TYPE','WORD'])['COUNT'].agg('sum').reset_index()

    api.send(outports[1]['name'], api.Message(attributes=att_dict, body=df))
    api.send(outports[0]['name'],log_stream.getvalue())


inports = [{'name': 'words', 'type': 'message.DataFrame', "description": "Message table."}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message.DataFrame', "description": "Table after regex"}]

api.set_port_callback(inports[0]['name'], process)


def test_operator():

    config = api.config
    config.debug_mode = True
    config.test_mode = False
    config.language_filter = 'None'
    config.word_types = 'None'
    api.set_config(config)

    doc_file = '/Users/Shared/data/onlinemedia/data/word_extraction.csv'
    df = pd.read_csv(doc_file,sep=',',nrows=10000000)
    msg = api.Message(attributes={'file': {'path': doc_file},'format':'pandas'}, body=df)
    process(msg)

    out_file = '/Users/Shared/data/onlinemedia/data/word_freq_test.csv'
    df_list = [d.body for d in api.queue]
    pd.concat(df_list).to_csv(out_file,index=False)



