import json
import os
import csv
import pandas as pd
import numpy as np
import re
import pickle
import collections
import subprocess

import spacy

import sdi_utils.gensolution as gs
import sdi_utils.set_logging as slog
import sdi_utils.textfield_parser as tfp
import sdi_utils.tprogress as tp

# global variable settings




try:
    api
except NameError:
    class api:

        class Message:
            def __init__(self, body=None, attributes=""):
                self.body = body
                self.attributes = attributes

        def send(port, msg):
            if port == outports[1]['name']:
                print('Attributes: ')
                print(msg.attributes)
                print('Data')
                print(msg.body)


        def set_config(config):
            api.config = config

        class config:
            ## Meta data
            config_params = dict()
            tags = {'sdi_utils': '', 'spacy': ''}
            version = "0.1.0"
            operator_name = "sql_word_index"
            operator_description = "sql word index"
            operator_description_long = "Creates SQL statement for creating a word _index from text_word."
            add_readme = dict()

            debug_mode = True
            config_params['debug_mode'] = {'title': 'Debug mode',
                                           'description': 'Sending debug level information to log port',
                                           'type': 'boolean'}

            language = 'DE'
            config_params['language'] = {'title': 'Language',
                                               'description': 'Language for which the index should be created.',
                                               'type': 'string'}

            type_limit_map = 'None'
            config_params['type_limit_map'] = {'title': 'Limit of each type',
                                           'description': 'Minimum frequency of words for each type (map)',
                                           'type': 'string'}



def process():

    operator_name = 'sql_word_index'
    logger, log_stream = slog.set_logging(operator_name, api.config.debug_mode)
    logger.info("Main Process started. Logging level: {}".format(logger.level))
    time_monitor = tp.progress()

    language = tfp.read_value(api.config.language)
    type_limit = tfp.read_dict(api.config.type_limit_map)

    for i, [wtype, limit] in enumerate(type_limit.items()) :
        sql_s = "SELECT TEXT_ID, TEXT_WORDS.LANGUAGE, TEXT_WORDS.TYPE, TEXT_WORDS.WORD, COUNT FROM TEXT_WORDS INNER JOIN"\
                "(SELECT WORD, TYPE, LANGUAGE, SUM(COUNT) as CUMS FROM TEXT_WORDS "\
                "WHERE LANGUAGE = \'{}\' AND TYPE = \'{}\' "\
                "GROUP BY WORD, TYPE, LANGUAGE) AS CTABLE ON "\
                "TEXT_WORDS.WORD = CTABLE.WORD AND TEXT_WORDS.TYPE = CTABLE.TYPE AND TEXT_WORDS.LANGUAGE = CTABLE.LANGUAGE "\
                "WHERE CUMS >= {}".format(language,wtype,limit)

        lastbatch = True if len(type_limit) == i+1 else False
        att_dict = attributes={'operator':operator_name,'parameter':{'type':wtype,'limit':limit,'language':language},\
                               'message.batchIndex':i,'message.batchSize':len(type_limit),'message.lastBatch':lastbatch}
        msg = api.Message(attributes=att_dict,body = sql_s)
        api.send(outports[1]['name'], msg)

    api.send(outports[0]['name'], log_stream.getvalue())



outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message', "description": "sql statement"}]

api.add_generator(process)


def test_operator():

    config = api.config
    config.debug_mode = True
    config.type_limit_map = 'LEX: 1, PROPN: 5, PER:2, ORG:2, LOC:2'
    config.language = 'DE'
    api.set_config(config)
    process()

