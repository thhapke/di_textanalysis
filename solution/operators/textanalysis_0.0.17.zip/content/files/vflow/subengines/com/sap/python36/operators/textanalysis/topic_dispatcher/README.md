# Topic dispatcher - textanalysis.topic_dispatcher (Version: 0.0.1)

Sends input topics to SQL processor and topic frequency operator.

## Inport

