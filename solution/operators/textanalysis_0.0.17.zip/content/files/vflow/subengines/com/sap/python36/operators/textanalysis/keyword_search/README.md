# Search Keywords - textanalysis.keyword_search (Version: 0.0.1)

Search Keywords

## Inport

* **articles** (Type: message) Message with body as dictionary 
* **keywords** (Type: message) Message with keywords to search 

## outports

* **log** (Type: string) Logging data
* **data** (Type: message.Dictionary) Output List of index words

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port


# Tags
sdi_utils : 

