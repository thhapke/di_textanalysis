# Line to array - sdi_utils_operators.string_collector (Version: 0.0.1)

Converts lines to array

## Inport

* **string** (Type: string) Input string
* **trigger** (Type: any) Trigger input

## outports

* **string** (Type: string) Output collected string

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port
* **threshold_size** - Threshold size (Type: integer) Threshold by which string is send. 


# Tags
sdi_utils : 

